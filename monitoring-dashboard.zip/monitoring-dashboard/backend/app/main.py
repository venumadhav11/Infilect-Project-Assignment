
from fastapi import FastAPI
from fastapi.responses import JSONResponse
import random
import time

app = FastAPI()

counter = 0

@app.get("/metrics")
def get_metrics():
    global counter
    counter += 1
    metrics = {
        "cpu_usage": round(random.uniform(10, 90), 2),
        "latency": round(random.uniform(50, 300), 2),
        "active_users": random.randint(10, 100),
        "counter": counter,
        "timestamp": int(time.time())
    }
    return JSONResponse(content=metrics)
